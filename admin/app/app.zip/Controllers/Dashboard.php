<?php

namespace App\Controllers;

use App\Core\MyController;
use App\Models\Sitefunction;

class Dashboard extends MyController
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Kolkata');
        $this->utc_time = date('Y-m-d H:i:s');
        $this->utc_date = date('Y-m-d');
        $this->dataModule = array();
        $this->dataModule['controller'] = $this;
    }

    public function index()
    {
        echo view('dashboard/index.php', $this->dataModule);
    }

    //Change user status

    public function change_visibility()
    {
        $requestData = $this->request->getJson();
        $id = $requestData->id;
        $status = $requestData->status;
        $adminId = $this->verify();
        if ($adminId != -1) {
            $model = new Sitefunction();
            $model->protect(false);
            $data_array = array('status' => $status, 'updated' => $this->utc_time);
            $updateResult = $model->update_data(TBL_CLIENT_COMPANIES, $data_array,  array('id' => $id));
            $model = new Sitefunction();
            $name = $model->get_single_row(TBL_CLIENT_COMPANIES, '*', array('id' => $id));
            $stat = "";
            if ($status == 1) {
                $stat = "Available";
            } else {
                $stat = "Unavailable";
            }
            if ($updateResult) {
                $action = 'Admin ID ' . $adminId . ' and name ' . $this->session->get('admin_name') . ' changed status of client company ' . $name['client_name'] . ' to ' . $stat;
                $this->addMemberlog($action);
                $data = array(
                    'message' => 'Client company status updated Successfully '
                );
                $this->dataModule = $this->success($data);
            }
        } else {
            $this->dataModule = $this->failure(302);
        }
        return $this->respond($this->dataModule);
    }
}
