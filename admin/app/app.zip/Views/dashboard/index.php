<?php include(INCLUDESPATH . '/header.php'); ?>
<?php include(INCLUDESPATH . '/sidebar.php'); ?>
<div class="content-wrap">
    <div class="main">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8 p-0">
                    <div class="page-header">
                        <div class="page-title">
                            <h3>DASHBOARD</h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 p-0">
                    <div class="page-header">
                        <div class="page-title">
                            <span class="pull-right">
                                <ol class="breadcrumb float-right">
                                    <li><a href="<?= DASHBOARD_PATH ?>">Dashboard</a></li>
                                </ol>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row custom-stat-widget">
                <div class="col-lg-2">
                    <div class="card">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="fa fa-industry  text-orange"></i>
                                <div class="stat-digit"><?php echo $clients ?></div>
                            </div>
                            <a class="text-blue" href="<?= SUBADMIN_PATH ?>">
                                <div class="stat-content dib">
                                    <div class="text-blue">Sub Admins</div>

                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="card">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="fa fa-warehouse   text-orange"></i>
                                <div class="stat-digit"><?php echo $vendors ?></div>
                            </div>
                            <a href="#">
                                <div class="stat-content dib">
                                    <div class="text-blue">Whatsapp Messages Sent</div>

                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="card">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="fa fa-user  text-orange"></i>
                                <div class="stat-digit"><?php echo $subadmins ?></div>
                            </div>
                            <a href="#">
                                <div class="stat-content dib">
                                    <div class="text-blue">Whatsapp Messages Recieved</div>

                                </div>
                            </a>
                        </div>
                    </div>
                </div>








            </div>
            <div class="main-content">
                <?php if (isset($success_message) && $success_message != '') {  ?>
                    <div class="alert alert-info alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success!</strong>
                        <?php echo isset($success_message) ? $success_message : $this->session->flashdata('invalid'); ?>
                    </div>
                <?php  } ?>
                <?php if (isset($error_message) && $error_message != '') {  ?>
                    <div class="alert alert-info alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error!</strong>
                        <?php echo isset($error_message) ? $error_message : $this->session->flashdata('invalid'); ?>
                    </div>
                <?php } ?>
            </div><!-- /# row -->
        </div>
    </div><!-- /# main content -->
</div><!-- /# container-fluid -->
</div><!-- /# main -->
</div><!-- /# content wrap -->

<?php include(INCLUDESPATH . "/footer.php") ?>
<script type="text/javascript">
    $(document).on('change', '.status_change ', function() {
        if ($(this).is(":checked")) {
            var visibility = '1';

        } else {
            var visibility = '0';
        }
        var id = $(this).attr('data-id');
        $.ajax({
            type: "POST",
            datatype: "json",
            crossDomain: true,
            url: "<?= DASHBOARD_PATH ?>/change_visibility",
            data: JSON.stringify({
                'id': id,
                'status': visibility
            }),
            headers: ({
                Authorization: "<?= $controller->session->get("jwtToken") ?>"
            }),
            success: function(data) {
                if (data.success == true) {
                    console.log(data);
                } else {
                    window.location.reload();
                }
            },
            error: function(data) {
                console.log("error is" + JSON.stringify(data));
            }
        });
    });
</script>
<script>
    function getRandomColor() {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    function poolColors(a) {
        var pool = [];
        for (i = 0; i < a; i++) {
            pool.push(getRandomColor());
        }
        return pool;
    }

    var colors = ['#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231', '#911eb4', '#46f0f0', '#f032e6', '#bcf60c', '#fabebe', '#008080', '#e6beff', '#9a6324', '#fffac8', '#800000', '#aaffc3', '#808000', '#ffd8b1', '#000075', '#808080', '#000000']
</script>
<script>
    $(document).ready(function() {
        var ctx1 = $("#InventoryBarchart");
        $.ajax({
            url: "<?= SUBADMIN_PATH ?>/inventory_graph",
            datatype: "json",
            type: 'POST',
            crossDomain: true,
            headers: ({
                Authorization: <?= "'" . $controller->session->get('jwtToken') . "'" ?>
            }),
            success: function(data) {

                var arrdata = data.tool;
                document.getElementById("download-InstockToolsQuantity").addEventListener('click', function() {
                    /*Get image of canvas element*/
                    var url_base64jp = document.getElementById("InventoryBarchart").toDataURL("image/jpg");
                    /*get download button (tag: <a></a>) */
                    var a = document.getElementById("download-InstockToolsQuantity");
                    /*insert chart image url to download button (tag: <a></a>) */
                    a.href = url_base64jp;
                });

                var chartData = {
                    labels: data.tool,
                    datasets: [{
                        label: "Instock Quantity",
                        backgroundColor: poolColors(arrdata.length),
                        data: data.tools_quantity
                    }]
                };

                var config = new Chart(ctx1, {
                    type: 'bar',
                    data: chartData,
                    options: {
                        legend: {
                            display: false
                        },
                        title: {
                            display: true,
                            text: 'Instock Tools Quantity',
                            fontSize: 15,
                            fontColor: '#000'
                        },
                        animation: {
                            duration: 1000,
                            easing: 'easeOutQuart',
                            onComplete: function() {
                                var ctx = this.chart.ctx;
                                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                                ctx.textAlign = 'center';
                                ctx.textBaseline = 'bottom';
                                chartData.datasets.forEach(function(dataset) {
                                    for (var i = 0; i < dataset.data.length; i++) {
                                        var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                            scale_max = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._yScale.maxHeight;
                                        ctx.fillStyle = '#444';
                                        var y_pos = model.y - 5;
                                        // Make sure data value does not get overflown and hidden
                                        // when the bar's value is too close to max value of scale
                                        // Note: The y value is reverse, it counts from top down
                                        if ((scale_max - model.y) / scale_max >= 0.93)
                                            y_pos = model.y + 20;
                                        ctx.fillText(dataset.data[i], model.x, y_pos);
                                    }
                                });
                            }

                        }
                    },
                });

            },
            error: function(data) {
                console.log("error is" + JSON.stringify(data));
            }
        });
    });
</script>
<script>
    $("#tool").on("change", function() {

        var id = $(this).val();
        if (id == 0) {

            $("#linechartforordertool").remove();
            $('#ToolsOrderDateVsRequiredTools').append('<canvas id="linechartforordertool"><canvas>');
            var ctx1 = $("#linechartforordertool");
            $.ajax({
                url: "<?= SUBADMIN_PATH ?>/all_tools_order",
                datatype: "json",
                type: 'POST',
                crossDomain: true,
                headers: ({
                    Authorization: <?= "'" . $controller->session->get('jwtToken') . "'" ?>
                }),
                success: function(data) {
                    $('#ToolsOrderDateVsRequiredToolscard').css('display', 'block');
                    const jsonObject = JSON.stringify(data.toolwiseData);
                    document.getElementById("download-ToolsOrderDateVsRequiredTools").addEventListener('click', function() {
                        /*Get image of canvas element*/
                        var url_base64jp = document.getElementById("linechartforordertool").toDataURL("image/jpg");
                        /*get download button (tag: <a></a>) */
                        var a = document.getElementById("download-ToolsOrderDateVsRequiredTools");
                        /*insert chart image url to download button (tag: <a></a>) */
                        a.href = url_base64jp;
                    });
                    var dataSetarray = [];
                    var createdArray = [];
                    var toolsname = [];
                    var colorArray = [];
                    var finalArray = [];
                    var finalcreatedArray = [];
                    for (let i = 0; i < data.toolwiseData.length; i++) {

                        colorArray.push(poolColors(data.toolwiseData.length));
                        for (let j = 0; j < data.toolwiseData[i].length; j++) {
                            if (j == 0) {
                                toolsname.push(data.toolwiseData[i][j].tool_name + " - " + data.toolwiseData[i][j].tool_no);
                                dataSetarray.push({
                                    x: data.toolwiseData[i][j].created,
                                    y: data.toolwiseData[i][j].required_tools
                                });

                                createdArray.push(data.toolwiseData[i][j].created);
                                // dataSetarray.push(data.toolwiseData[i][j].required_tools);
                            } else {
                                dataSetarray.push({
                                    x: data.toolwiseData[i][j].created,
                                    y: data.toolwiseData[i][j].required_tools
                                });
                                createdArray.push(data.toolwiseData[i][j].created);
                                // dataSetarray.push(data.toolwiseData[i][j].required_tools);
                            }
                        }
                        // dataset = [{
                        //         x: createdArray,
                        //         y: required_tools
                        //     },
                        //     {
                        //         x: createdArray,
                        //         y: required_tools
                        //     }
                        // ]
                        finalArray.push({
                            label: toolsname[i],
                            data: dataSetarray,
                            fill: false,
                            borderColor: colors[Math.floor(Math.random() * colors.length)],
                            tension: 0.1
                        });
                        dataSetarray = [];
                    }
                    // console.log(finalArray);
                    function removeDuplicates(arr) {
                        return arr.filter((item,
                            index) => arr.indexOf(item) === index);
                    }
                    var sortedArray = removeDuplicates(createdArray).sort();
                    var data1 = {
                        labels: sortedArray,
                        datasets: finalArray
                    };
                    var config = new Chart(ctx1, {
                        type: 'line',
                        options: {
                            title: {
                                display: true,
                                text: 'Tools Order Date Vs Required Tools',
                                fontSize: 15,
                                fontColor: '#000'
                            },
                            animation: {
                                duration: 1000,
                                easing: 'easeOutQuart',
                                onComplete: function() {
                                    var ctx = this.chart.ctx;
                                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                                    ctx.textAlign = 'center';
                                    ctx.textBaseline = 'bottom';
                                    data1.datasets.forEach(function(dataset) {
                                        for (var i = 0; i < dataset.data.length; i++) {
                                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                                scale_max = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._yScale.maxHeight;
                                            ctx.fillStyle = '#444';
                                            var y_pos = model.y - 5;
                                            // Make sure data value does not get overflown and hidden
                                            // when the bar's value is too close to max value of scale
                                            // Note: The y value is reverse, it counts from top down
                                            if ((scale_max - model.y) / scale_max >= 0.93)
                                                y_pos = model.y + 20;
                                            ctx.fillText(dataset.data[i].y, model.x, y_pos);
                                        }
                                    });
                                }

                            }

                        },
                        data: data1,
                    });
                },
                error: function(data) {
                    $('#ToolsOrderDateVsRequiredToolscard').css('display', 'none');
                    console.log("error is" + JSON.stringify(data));
                }
            });
        } else {

            $("#linechartforordertool").remove();
            $('#ToolsOrderDateVsRequiredTools').append('<canvas id="linechartforordertool"><canvas>');
            var ctx1 = $("#linechartforordertool");
            $.ajax({
                url: "<?= SUBADMIN_PATH ?>/required_tools_bargraph",
                datatype: "json",
                type: 'POST',
                crossDomain: true,
                data: JSON.stringify({
                    "id": id,
                }),
                headers: ({
                    Authorization: <?= "'" . $controller->session->get('jwtToken') . "'" ?>
                }),
                success: function(data) {
                    $('#ToolsOrderDateVsRequiredToolscard').css('display', 'block');
                    var arrdata = data.created;
                    document.getElementById("download-ToolsOrderDateVsRequiredTools").addEventListener('click', function() {
                        /*Get image of canvas element*/
                        var url_base64jp = document.getElementById("linechartforordertool").toDataURL("image/jpg");
                        /*get download button (tag: <a></a>) */
                        var a = document.getElementById("download-ToolsOrderDateVsRequiredTools");
                        /*insert chart image url to download button (tag: <a></a>) */
                        a.href = url_base64jp;
                    });
                    var data1 = {
                        labels: data.created,
                        datasets: [{
                            label: data.tool[0],
                            data: data.required_tools,
                            fill: false,
                            borderColor: colors[Math.floor(Math.random() * colors.length)],
                            tension: 0.1
                        }]
                    };
                    var config = new Chart(ctx1, {
                        type: 'line',
                        options: {
                            title: {
                                display: true,
                                text: 'Tool Order Date Vs Required Tools',
                                fontSize: 15,
                                fontColor: '#000'
                            },
                            animation: {
                                duration: 1000,
                                easing: 'easeOutQuart',
                                onComplete: function() {
                                    var ctx = this.chart.ctx;
                                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                                    ctx.textAlign = 'center';
                                    ctx.textBaseline = 'bottom';
                                    data1.datasets.forEach(function(dataset) {
                                        for (var i = 0; i < dataset.data.length; i++) {
                                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                                scale_max = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._yScale.maxHeight;
                                            ctx.fillStyle = '#444';
                                            var y_pos = model.y - 5;
                                            // Make sure data value does not get overflown and hidden
                                            // when the bar's value is too close to max value of scale
                                            // Note: The y value is reverse, it counts from top down
                                            if ((scale_max - model.y) / scale_max >= 0.93)
                                                y_pos = model.y + 20;
                                            ctx.fillText(dataset.data[i], model.x, y_pos);
                                        }
                                    });
                                }

                            }

                        },
                        data: data1,

                    });
                },
                error: function(data) {
                    $('#ToolsOrderDateVsRequiredToolscard').css('display', 'none');
                    console.log("error is" + JSON.stringify(data));
                }
            });
        }
    });
</script>
<script>
    $(document).ready(function() {
        var ctx1 = $("#linechartforordertool");
        $.ajax({
            url: "<?= SUBADMIN_PATH ?>/all_tools_order",
            datatype: "json",
            type: 'POST',
            crossDomain: true,
            headers: ({
                Authorization: <?= "'" . $controller->session->get('jwtToken') . "'" ?>
            }),
            success: function(data) {
                const jsonObject = JSON.stringify(data.toolwiseData);
                document.getElementById("download-ToolsOrderDateVsRequiredTools").addEventListener('click', function() {
                    /*Get image of canvas element*/
                    var url_base64jp = document.getElementById("linechartforordertool").toDataURL("image/jpg");
                    /*get download button (tag: <a></a>) */
                    var a = document.getElementById("download-ToolsOrderDateVsRequiredTools");
                    /*insert chart image url to download button (tag: <a></a>) */
                    a.href = url_base64jp;
                });
                var dataSetarray = [];
                var createdArray = [];
                var toolsname = [];
                var colorArray = [];
                var finalArray = [];
                var finalcreatedArray = [];
                for (let i = 0; i < data.toolwiseData.length; i++) {
                    colorArray.push(poolColors(data.toolwiseData.length));
                    for (let j = 0; j < data.toolwiseData[i].length; j++) {
                        if (j == 0) {
                            toolsname.push(data.toolwiseData[i][j].tool_name + " - " + data.toolwiseData[i][j].tool_no);
                            dataSetarray.push({
                                x: data.toolwiseData[i][j].created,
                                y: data.toolwiseData[i][j].required_tools
                            });

                            createdArray.push(data.toolwiseData[i][j].created);
                            // dataSetarray.push(data.toolwiseData[i][j].required_tools);
                        } else {
                            dataSetarray.push({
                                x: data.toolwiseData[i][j].created,
                                y: data.toolwiseData[i][j].required_tools
                            });
                            createdArray.push(data.toolwiseData[i][j].created);
                            // dataSetarray.push(data.toolwiseData[i][j].required_tools);
                        }

                    }
                    // dataset = [{
                    //         x: createdArray,
                    //         y: required_tools
                    //     },
                    //     {
                    //         x: createdArray,
                    //         y: required_tools
                    //     }
                    // ]
                    finalArray.push({
                        label: toolsname[i],
                        data: dataSetarray,
                        fill: false,
                        borderColor: colors[Math.floor(Math.random() * colors.length)],
                        tension: 0.1
                    });
                    dataSetarray = [];
                }

                function removeDuplicates(arr) {
                    return arr.filter((item,
                        index) => arr.indexOf(item) === index);
                }
                var sortedArray = removeDuplicates(createdArray).sort();
                var data1 = {
                    labels: sortedArray,
                    datasets: finalArray
                };
                var config = new Chart(ctx1, {
                    type: 'line',
                    options: {
                        title: {
                            display: true,
                            text: 'Tools Order Date Vs Required Tools',
                            fontSize: 15,
                            fontColor: '#000'
                        },
                        animation: {
                            duration: 1000,
                            easing: 'easeOutQuart',
                            onComplete: function() {
                                var ctx = this.chart.ctx;
                                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                                ctx.textAlign = 'center';
                                ctx.textBaseline = 'bottom';
                                data1.datasets.forEach(function(dataset) {
                                    for (var i = 0; i < dataset.data.length; i++) {
                                        var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                                            scale_max = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._yScale.maxHeight;
                                        ctx.fillStyle = '#444';
                                        var y_pos = model.y - 5;
                                        // Make sure data value does not get overflown and hidden
                                        // when the bar's value is too close to max value of scale
                                        // Note: The y value is reverse, it counts from top down
                                        if ((scale_max - model.y) / scale_max >= 0.93)
                                            y_pos = model.y + 20;
                                        ctx.fillText(dataset.data[i].y, model.x, y_pos);
                                    }
                                });
                            }

                        }
                    },
                    data: data1,
                });
            },
            error: function(data) {

                console.log("error is" + JSON.stringify(data));
            }
        });
    });
</script>


<?php include(INCLUDESPATH . "/close.php"); ?>